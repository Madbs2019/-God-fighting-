## fixes
- cloud shadows broken on OptiFine

## features
- rework rainy weather
- water texture visible in low skylight

### sky
- noctilucent clouds
- bring back cirrocumulus clouds?
- improve aurora
